# ESP32 HVAC Thermostat

An advanced HVAC thermostat firmware for ESP32 with:

- WebSocket & REST API
- OTA updates via ArduinoOTA
- mDNS discovery for `http://esp32-thermo.local`
- JSON state push to `/ws`
- Persistent settings (NVS via Preferences)
- OLED display (Adafruit SSD1306)
- DHT22 temperature sensor
- Daily min/max logging
- Hysteresis control
- Status LED

## Usage

1. Clone or download the project.
2. Open `esp32_thermostat.ino` in Arduino IDE.
3. Install required libraries:
   - AsyncTCP
   - ESPAsyncWebServer
   - ArduinoJson
   - Preferences
   - Ticker
   - DHT sensor library
   - Adafruit SSD1306
   - ESPmDNS
   - ArduinoOTA
4. Set your Wi-Fi credentials in the sketch.
5. Upload to your ESP32.
6. Access status at `http://<esp-ip>/api/status` or `ws://<esp-ip>/ws` for real-time updates.
